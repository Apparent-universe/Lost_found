<template>
    <div class="profile">
        <h2>个人信息</h2>
        <div class="form">
            <input v-model="form.contact" placeholder="联系方式" />
            <input v-model="form.free_time" placeholder="空闲时间" />
            <textarea v-model="form.personal_info" placeholder="简介" rows="4" />
            <ImageUploader :url="form.wx_qrcode" @update:url="value => form.wx_qrcode = value" />
            <button @click="save">保存</button>
        </div>
    </div>
</template>

<script setup>
import { onMounted, reactive } from 'vue'
import { getProfile, updateProfile } from '@/api/user'
import ImageUploader from '@/components/ImageUploader.vue'

const form = reactive({ contact: '', free_time: '', personal_info: '', wx_qrcode: '' })

onMounted(async () => {
    const data = await getProfile()
    Object.assign(form, data)
})

const save = async () => {
    await updateProfile(form)
    alert('保存成功')
}
</script>

<style scoped>
.profile {
    max-width: 600px;
    margin: 60px auto;
}

input,
textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 12px;
    border-radius: 6px;
    border: 1px solid #ccc;
}

button {
    padding: 10px 20px;
    background: #007aff;
    color: white;
    border: none;
    border-radius: 6px;
}
</style>