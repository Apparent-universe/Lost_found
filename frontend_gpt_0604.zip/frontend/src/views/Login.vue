<template>
    <div class="login-page">
        <h2 class="title">用户登录</h2>
        <div class="form">
            <input v-model="username" placeholder="用户名" />
            <input v-model="password" type="password" placeholder="密码" />
            <button @click="login">登录</button>
        </div>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { loginApi } from '@/api/user'
import { useUserStore } from '@/store/user'


const username = ref('')
const password = ref('')
const router = useRouter()
const userStore = useUserStore()

const login = async () => {
    try {
        const res = await loginApi({ username: username.value, password: password.value })
        userStore.setToken(res.token)
        userStore.setRole(res.role)
        router.push(res.role === 'admin' ? '/admin' : '/profile')
    } catch (err) {
        alert('登录失败，请检查用户名或密码')
    }
}
</script>

<style scoped>
.login-page {
    max-width: 400px;
    margin: 100px auto;
    padding: 2rem;
    box-shadow: 0 0 10px #ccc;
    border-radius: 8px;
    text-align: center;
}

input {
    width: 100%;
    padding: 10px;
    margin-bottom: 12px;
    border-radius: 6px;
    border: 1px solid #ccc;
}

button {
    width: 100%;
    padding: 10px;
    background: #007aff;
    color: white;
    border: none;
    border-radius: 6px;
}
</style>