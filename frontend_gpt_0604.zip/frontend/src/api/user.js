import axios from 'axios'

const base = 'http://localhost:8000/users'

const token = () => localStorage.getItem('token')

const authHeaders = () => ({ headers: { Authorization: token() } })

export const loginApi = data => axios.post(`${base}/login/`, data).then(res => res.data)
export const getProfile = () => axios.get(`${base}/profile/`, authHeaders()).then(res => res.data)
export const updateProfile = data => axios.put(`${base}/profile/`, data, authHeaders())
export const uploadQRCode = formData => axios.post(`${base}/upload_qrcode/`, formData, authHeaders()).then(res => res.data)
