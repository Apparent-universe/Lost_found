<template>
    <div>
        <label>上传微信收款码：</label><br>
        <input type="file" @change="upload" />
        <div v-if="url"><img :src="url" alt="二维码" width="120" /></div>
    </div>
</template>

<script setup>
import { uploadQRCode } from '@/api/user'
import { ref, watch } from 'vue'

const props = defineProps({ modelValue: String })
const emit = defineEmits(['update:url'])
const url = ref(props.modelValue)

watch(() => props.modelValue, val => url.value = val)

const upload = async (e) => {
    const file = e.target.files[0]
    const formData = new FormData()
    formData.append('file', file)
    const res = await uploadQRCode(formData)
    url.value = res.url
    emit('update:url', res.url)
}
</script>