import { createRouter, createWebHistory } from 'vue-router'
import Login from '@/views/Login.vue'
import Profile from '@/views/Profile.vue'

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: Login },
  { path: '/profile', component: Profile },
]

export default createRouter({
  history: createWebHistory(),
  routes,
})
