import { defineStore } from 'pinia'

// 使用 Pinia 管理 token 和角色
export const useUserStore = defineStore('user', {
  state: () => ({
    token: localStorage.getItem('token') || '',
    role: localStorage.getItem('role') || ''
  }),
  actions: {
    setToken(t) {
      this.token = t
      localStorage.setItem('token', t)
    },
    setRole(r) {
      this.role = r
      localStorage.setItem('role', r)
    },
    logout() {
      this.token = ''
      this.role = ''
      localStorage.clear()
    }
  }
})
