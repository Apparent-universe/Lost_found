<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script setup>
// 无需写任何内容，路由组件自动挂载
</script>

<style>
/* 全局样式建议加一点，提升视觉体验 */
body {
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif;
  background-color: #f6f6f6;
}
#app {
  padding: 20px;
}
</style>
